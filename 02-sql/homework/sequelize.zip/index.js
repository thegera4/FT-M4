const { Sequelize, Model, DataTypes, Op } = require("sequelize");
const express = require("express");

const db = new Sequelize("postgres://postgres:postgres@localhost:5432/henry", {
  logging: false,
});

class Student extends Model {}

Student.init(
  {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    surname: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true,
      },
      set(value) {
        this.setDataValue("email", value.toLowerCase());
      },
    },
    countryId: {
      type: DataTypes.STRING(3),
      allowNull: true,
      defaultValue: "ARG",
    },
    displayName: {
      type: DataTypes.VIRTUAL,
      get() {
        return `${this.name} ${this.surname}`;
      },
    },
  },
  {
    sequelize: db,
    modelName: "student",
    updatedAt: false,
  }
);

class Cohort extends Model {}
Cohort.init(
  {
    cohort: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
  },
  {
    sequelize: db,
    modelName: "cohort",
  }
);

Cohort.hasMany(Student);
Student.belongsTo(Cohort);

const app = express();

app.get("/students", (req, res) => {
  if (req.query.search) {
    return Student.findAll({
      where: {
        [Op.or]: [
          { name: { [Op.like]: `%${req.query.search}%` } },
          { surname: { [Op.like]: `%${req.query.search}%` } },
          { email: { [Op.like]: `%${req.query.search}%` } },
        ],
      },
    }).then((students) => {
      res.json(students);
    });
  }

  Student.findAll({}).then((students) => {
    res.json(students);
  });
});

app.get("/students/:id", (req, res) => {
  Student.findByPk(req.params.id, { include: Cohort })
    .then((student) => {
      if (!student) {
        return res.status(404).json({
          error: "Student not found",
        });
      }
      res.json(student);
    })
    .catch((err) => {
      res.status(404).json({
        error: "Student not found",
      });
    });
});

db.sync({ alter: true }).then(() => {
  app.listen(3030, () => {
    console.log("Server running on port 3030");
  });
});
